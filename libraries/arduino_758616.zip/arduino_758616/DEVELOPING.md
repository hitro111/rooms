# Developing

1. Commit changes.
2. Update version with `bump.sh 1.0.0 2.0.0`.
3. Generate zip with `gulp`.
4. Create release on GitHub.
5. Upload `mqtt.zip`.
